function logout() {
    localStorage.removeItem("userDetailRide");
    window.location.href = "./index.html";
  }
  